// Register the @nanmicoder/dsh-agent-teams bundle into $DSH_HOME/cordis.patch.yml (idempotent).
// Usage: node patch-agent-teams.mjs <path-to-cordis.patch.yml>
import { readFileSync, appendFileSync } from 'node:fs';

const target = process.argv[2];
if (!target) {
  console.error('usage: node patch-agent-teams.mjs <cordis.patch.yml>');
  process.exit(1);
}

const marker = '@nanmicoder/dsh-agent-teams';
let txt = '';
try {
  txt = readFileSync(target, 'utf8');
} catch {}

if (txt.includes(marker)) {
  console.log('already registered');
  process.exit(0);
}

const block =
  '\n- insert:\n' +
  "    - id: agent-teams\n" +
  "      name: '@nanmicoder/dsh-agent-teams'\n" +
  '      config: {stateDir: .agent-teams, memberProvider: spawn}\n';

appendFileSync(target, block);
console.log('registered');