@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
rem @nanmicoder/dsh-agent-teams offline installer for DeepSeek Harness.
rem Copies the plugin and its two missing peer UI packages into the web profile's
rem node_modules (%DSH_HOME%\profiles\web\node_modules) - the location dsh's
rem loader resolves plugin bundles from - then registers the agent-teams bundle
rem in %DSH_HOME%\cordis.patch.yml. All other peer deps resolve via dsh's
rem maintained %DSH_HOME%\profiles\node_modules fallback.
rem No network, no pnpm, nothing scattered.
rem Usage: install.cmd ["<dsh data home>"]   (overrides DSH_HOME if given)

set "HERE=%~dp0"
if not defined DSH_HOME set "DSH_HOME=%USERPROFILE%\.dsh"
if not "%~1"=="" set "DSH_HOME=%~1"

set "P=%DSH_HOME%\profiles\web\node_modules"
echo Installing into profile: "%P%"
mkdir "%P%\@nanmicoder" 2>nul
mkdir "%P%\@deepseek-ai" 2>nul

echo [1/3] Copying plugin into "%P%\@nanmicoder\dsh-agent-teams"...
if exist "%P%\@nanmicoder\dsh-agent-teams" rmdir /S /Q "%P%\@nanmicoder\dsh-agent-teams"
xcopy /E /I /Y "%HERE%plugin" "%P%\@nanmicoder\dsh-agent-teams" >nul
if errorlevel 1 ( echo [ERROR] plugin copy failed. & exit /b 1 )

echo [2/3] Ensuring missing peer UI packages present...
if not exist "%P%\@deepseek-ai\dsh-client-ui-primitives\package.json" xcopy /E /I /Y "%HERE%deps\@deepseek-ai\dsh-client-ui-primitives" "%P%\@deepseek-ai\dsh-client-ui-primitives" >nul
if not exist "%P%\@deepseek-ai\dsh-client-ui-slots\package.json" xcopy /E /I /Y "%HERE%deps\@deepseek-ai\dsh-client-ui-slots" "%P%\@deepseek-ai\dsh-client-ui-slots" >nul

echo [3/3] Registering agent-teams patch in "%DSH_HOME%\cordis.patch.yml"...
if not exist "%DSH_HOME%" mkdir "%DSH_HOME%"
node "%HERE%scripts\patch-agent-teams.mjs" "%DSH_HOME%\cordis.patch.yml"
if errorlevel 1 ( echo [ERROR] patch failed. & exit /b 1 )

echo.
echo [OK] Done. Restart dsh, then AgentTeams is available.
endlocal
exit /b 0