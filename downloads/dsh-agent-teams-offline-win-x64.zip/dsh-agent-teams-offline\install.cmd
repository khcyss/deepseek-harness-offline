@echo off
chcp 65001 >nul
setlocal
rem @nanmicoder/dsh-agent-teams offline installer for DeepSeek Harness.
rem Usage: install.cmd ["<path-to-dsh-bin.js>"]   (optional first arg overrides the dsh lib/bin.js location)

set "HERE=%~dp0"

rem --- locate dsh launcher bin ---
set "DSH_BIN=D:\deepseek-harness\bundle\node_modules\@deepseek-ai\dsh\lib\bin.js"
if not "%~1"=="" set "DSH_BIN=%~1"
if not exist "%DSH_BIN%" (
  echo [ERROR] dsh bin not found: "%DSH_BIN%"
  echo         Pass the real path as an argument, e.g.:
  echo         install.cmd "D:\deepseek-harness\bundle\node_modules\@deepseek-ai\dsh\lib\bin.js"
  exit /b 1
)

rem --- pnpm must be on PATH ---
where pnpm >nul 2>nul
if errorlevel 1 (
  echo [ERROR] 'pnpm' not found on PATH.
  echo         Put the offline pnpm folder on PATH first ^(setx PATH "%%PATH%%;D:\pnpm-offline"^),
  echo         reopen this window, then run install.cmd again.
  exit /b 1
)

echo [1/1] Installing @nanmicoder/dsh-agent-teams via dsh plugin ^(offline^)...
node "%DSH_BIN%" plugin --profile web add "%HERE%plugin" --offline
if errorlevel 1 (
  echo [ERROR] plugin add failed. See output above.
  exit /b 1
)

echo [OK] Done. Restart dsh ^(close dsh.cmd and reopen^), then in a new session the agent_teams_* tools and the AgentTeams card are available.
endlocal
exit /b 0