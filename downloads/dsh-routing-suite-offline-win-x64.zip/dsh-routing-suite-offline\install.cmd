@echo off
chcp 65001 >nul
setlocal
rem dsh-routing-suite offline installer.
rem Usage: install.cmd ["<path-to-dsh-bin.js>"]   (optional first arg overrides the dsh lib/bin.js location)

set "HERE=%~dp0"

rem --- locate dsh launcher bin ---
set "DSH_BIN=D:\deepseek-harness\bundle\node_modules\@deepseek-ai\dsh\lib\bin.js"
if not "%~1"=="" set "DSH_BIN=%~1"
if not exist "%DSH_BIN%" (
  echo [ERROR] dsh bin not found: "%DSH_BIN%"
  echo         Pass the real path as an argument, e.g.:
  echo         install.cmd "D:\deepseek-harness\bundle\node_modules\@deepseek-ai\dsh\lib\bin.js"
  exit /b 1
)

rem --- pnpm must be on PATH ---
where pnpm >nul 2>nul
if errorlevel 1 (
  echo [ERROR] 'pnpm' not found on PATH.
  echo         Put the offline pnpm folder on PATH first ^(setx PATH "%%PATH%%;D:\pnpm-offline"^),
  echo         reopen this window, then run install.cmd again.
  exit /b 1
)

echo [1/3] Installing injector via dsh plugin ^(offline^)...
node "%DSH_BIN%" plugin --profile web add "%HERE%injector" --offline
if errorlevel 1 (
  echo [ERROR] injector add failed.
  exit /b 1
)

echo [2/3] Copying router presets into %USERPROFILE%\.dsh\.agent-presets...
set "AP=%USERPROFILE%\.dsh\.agent-presets"
if not exist "%AP%" mkdir "%AP%"
xcopy /E /I /Y "%HERE%preset\router-standard" "%AP%\router-standard" >nul
xcopy /E /I /Y "%HERE%preset\router-spec" "%AP%\router-spec" >nul
xcopy /E /I /Y "%HERE%preset\router-react" "%AP%\router-react" >nul

echo [3/3] Done. Restart dsh %^|close dsh.cmd and reopen^|, then in a new session pick a Router preset.
endlocal
exit /b 0