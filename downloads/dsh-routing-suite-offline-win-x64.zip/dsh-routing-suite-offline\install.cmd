@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
rem dsh-routing-suite offline installer (injector + router presets).
rem Copies the injector plugin and the bundle-missing peer deps (cordis,
rem schemastery) into %DSH_HOME%\profiles\web\node_modules (the location dsh
rem resolves plugins from), registers the dsh-super-injector patch in
rem %DSH_HOME%\cordis.patch.yml, and copies the Router presets into
rem %DSH_HOME%\.agent-presets. No network, no pnpm, no external symlinks.

set "HERE=%~dp0"
if not defined DSH_HOME set "DSH_HOME=%USERPROFILE%\.dsh"

set "NM=%DSH_HOME%\profiles\web\node_modules"

echo [1/3] Copying injector into "%NM%\@dsh-external\dsh-super-injector" ...
if not exist "%NM%\@dsh-external" mkdir "%NM%\@dsh-external"
if exist "%NM%\@dsh-external\dsh-super-injector" rmdir /S /Q "%NM%\@dsh-external\dsh-super-injector"
xcopy /E /I /Y "%HERE%injector" "%NM%\@dsh-external\dsh-super-injector" >nul
if errorlevel 1 ( echo [ERROR] injector copy failed. & exit /b 1 )

echo [2/3] Ensuring missing peer deps present (cordis, schemastery)...
if not exist "%NM%\cordis\package.json" xcopy /E /I /Y "%HERE%deps\cordis" "%NM%\cordis" >nul
if not exist "%NM%\schemastery\package.json" xcopy /E /I /Y "%HERE%deps\schemastery" "%NM%\schemastery" >nul

echo [3/3] Registering patch + copying Router presets...
if not exist "%DSH_HOME%" mkdir "%DSH_HOME%"
node "%HERE%scripts\patch-router-suite.mjs" "%DSH_HOME%\cordis.patch.yml"
if errorlevel 1 ( echo [ERROR] patch failed. & exit /b 1 )

set "AP=%DSH_HOME%\.agent-presets"
if not exist "%AP%" mkdir "%AP%"
xcopy /E /I /Y "%HERE%preset\router-standard" "%AP%\router-standard" >nul
xcopy /E /I /Y "%HERE%preset\router-spec" "%AP%\router-spec" >nul
xcopy /E /I /Y "%HERE%preset\router-react" "%AP%\router-react" >nul

echo.
echo [OK] Done. Restart dsh, then pick a Router preset / dev_* tools are available.
endlocal
exit /b 0