// Register the @dsh-external/dsh-super-injector bundle into $DSH_HOME/cordis.patch.yml (idempotent).
// Usage: node patch-router-suite.mjs <path-to-cordis.patch.yml>
import { readFileSync, appendFileSync } from 'node:fs';

const target = process.argv[2];
if (!target) {
  console.error('usage: node patch-router-suite.mjs <cordis.patch.yml>');
  process.exit(1);
}

const marker = '@dsh-external/dsh-super-injector';
let txt = '';
try {
  txt = readFileSync(target, 'utf8');
} catch {}

if (txt.includes(marker)) {
  console.log('already registered');
  process.exit(0);
}

const block =
  '\n- insert:\n' +
  "    - id: dsh-super-injector\n" +
  "      name: '@dsh-external/dsh-super-injector'\n" +
  '      config: {}\n';

appendFileSync(target, block);
console.log('registered');