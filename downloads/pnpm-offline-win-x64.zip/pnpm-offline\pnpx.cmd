@echo off
@node "%~dp0node_modules\pnpm\bin\pnpx.mjs" %*
exit /b %errorlevel%