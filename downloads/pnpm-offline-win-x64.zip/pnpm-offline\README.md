# pnpm 离线包（免安装）使用说明

本目录是 **pnpm 11.23.0** 的离线自包含版：依赖已在打包机预装为 `node_modules`，目标机**无需联网、无需安装**，只要把本目录加入 PATH 即可使用 `pnpm` 命令。

- 版本：pnpm 11.23.0
- 要求 Node.js：`>=22.13`（本目录走 `node` 运行，目标机需有 Node。）

## 第一步：放好位置（目标机）

把本 `pnpm-offline` 目录拷贝到离线机，例如 `D:\pnpm-offline`（解压后应能看到 `D:\pnpm-offline\pnpm.cmd`）。

## 第二步：把 pnpm 加进 PATH（关键，dsh 插件安装靠它）

```bat
setx PATH "%PATH%;D:\pnpm-offline"
```

> **必须重开一个新的终端/命令窗口**让 PATH 生效（`setx` 不改当前窗口）。

验证：

```bat
pnpm --version
```

看到 `11.23.0` 即成功。

## 第三步：给 dsh 装插件（离线场景）

`dsh plugin` 命令本质是在 dsh 的 profile 目录里执行 `pnpm`（从 PATH 取）。离线装插件三步：

1. **插件包文件必须已在本地**（U 盘拷过来）。支持：
   - 单个 `.tgz`：`dsh plugin --profile web add D:\plugins\my-plugin-1.0.0.tgz`
   - 或本地目录：`dsh plugin --profile web add D:\plugins\my-plugin`
2. **关闭 pnpm 的发布时间校验**（否则 pnpm≥10 在离线下会尝试联网校验导致 `ECONNREFUSED` 重试）：在 dsh 的 profile 目录 `%USERPROFILE%\.dsh\profiles\<profile>\pnpm-workspace.yaml` 末尾加一行：
   ```yaml
   minimumReleaseAge: 0
   ```
3. 插件若声明了**额外的依赖包**，而 n 那些依赖没随插件一起离线，pnpm 仍会尝试联网下载 → 会失败。因此**尽量选零依赖的插件**，或把依赖也一并准备好（见下）。

## 常见问题

| 现象 | 处理 |
| --- | --- |
| 提示找不到 `pnpm` 命令 | 确认 `D:\pnpm-offline` 已加进 PATH 并重开终端 |
| pnpm 卡在 `GET http://localhost:4873/...` 重试 | 是 `minimumReleaseAge` 校验在联网，给该 profile 的 `pnpm-workspace.yaml` 加 `minimumReleaseAge: 0` |
| 装插件报无法解析某依赖 | 该插件的依赖不在本地；需在有网机器把依赖打包一起带过来（可用 `npm pack` / `pnpm pack` 逐个拉 .tgz）|

## 说明

- 本包是通用工具，不绑定 dsh。也可以直接 `pnpm install` 其它离线项目（把包本身 .tgz 放本地路径装）。
- 若只需给 I dsh 用，装完 PATH 后无需其它配置。