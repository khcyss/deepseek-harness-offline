@echo off
@node "%~dp0node_modules\pnpm\bin\pnpm.mjs" %*
exit /b %errorlevel%