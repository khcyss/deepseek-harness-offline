@echo off
chcp 65001 >nul
setlocal
rem codesys-mcp-persistent server launcher (MCP stdio).
rem Usage: codesys.cmd [options...]  (passes through to dist/bin.js)
node "%~dp0server\dist\bin.js" %*
exit /b %errorlevel%